# fastmatrix

`fastmatrix` is a **Python package with a C++ backend**.

It keeps Python-side usability while moving the heavy numerical kernel into native code. The current version focuses on dense matrix operations and a multithreaded matrix multiplication kernel.

## Features

- Pythonic `Matrix` class
- C++ backend compiled during `pip install`
- Windows, Linux, macOS source-build support
- Multithreaded `matmul`
- Blocked multiplication for better cache locality
- Pre-transpose of `B` to improve memory access patterns

## Install

### Local source install

```bash
pip install .
```

### Editable install

```bash
pip install -e .
```

## Windows notes

On Windows, install **Microsoft C++ Build Tools** first so that `pip` can compile the extension.

Then run:

```powershell
pip install .
```

## Usage

```python
from fastmatrix import Matrix, hardware_threads

print(hardware_threads())

A = Matrix([[1, 2, 3], [4, 5, 6]])
B = Matrix([[7, 8], [9, 10], [11, 12]])

C = A @ B
print(C.numpy())
print(C.T.numpy())

D = A.matmul(B, threads=4, block_size=64)
print(D.numpy())
```

## Project layout

```text
fastmatrix_bridge/
├── pyproject.toml
├── setup.py
├── src/
│   └── fastmatrix/
│       ├── __init__.py
│       ├── backend.py
│       ├── matrix.py
│       └── _fastmatrix_native.cpp
├── example.py
├── benchmark.py
└── tests/
```
